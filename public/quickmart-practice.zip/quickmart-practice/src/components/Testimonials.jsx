
const Testimonials = () => {
  return (
    <section className="bg-gray-100 py-16 px-4 text-center">
      <h3 className="text-3xl font-semibold mb-8">What our customers say</h3>
      <div className="max-w-xl mx-auto text-gray-700 italic">
        "Amazing quality and fast delivery! I’m so happy with my purchase!"
      </div>
    </section>
  );
};

export default Testimonials;
