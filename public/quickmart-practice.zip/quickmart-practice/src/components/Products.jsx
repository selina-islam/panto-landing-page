
const products = [
  { id: 1, name: "Wristwatch", price: "$49", img: "https://via.placeholder.com/150" },
  { id: 2, name: "Handbag", price: "$65", img: "https://via.placeholder.com/150" },
  { id: 3, name: "Smartwatch", price: "$89", img: "https://via.placeholder.com/150" },
];

const Products = () => {
  return (
    <section className="py-16 px-4 text-center">
      <h3 className="text-3xl font-semibold mb-8">Popular Products</h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {products.map((product) => (
          <div key={product.id} className="bg-white p-4 shadow-md rounded-md">
            <img src={product.img} alt={product.name} className="w-full h-40 object-cover mb-4 rounded-md" />
            <h4 className="text-xl font-medium">{product.name}</h4>
            <p className="text-gray-600">{product.price}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Products;
