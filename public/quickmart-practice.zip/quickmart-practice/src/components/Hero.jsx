
const Hero = () => {
  return (
    <section className="bg-indigo-100 text-center py-20 px-4">
      <h2 className="text-4xl font-bold text-gray-800 mb-4">Welcome to QuickMart</h2>
      <p className="text-lg text-gray-600 mb-6">Discover the best products at amazing prices</p>
      <button className="bg-indigo-600 text-white px-6 py-2 rounded-md">Shop Now</button>
    </section>
  );
};

export default Hero;
